package com.iztech.udemycoursecatcher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UdemyCourseCatcherApplicationTests {

	@Test
	void contextLoads() {
	}

}
