package com.iztech.udemycoursecatcher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UdemyCourseCatcherApplication {

	public static void main(String[] args) {
		SpringApplication.run(UdemyCourseCatcherApplication.class, args);
	}

}
